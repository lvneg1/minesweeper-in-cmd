#include <windows.h>

void gotoxy(short x,short y) {
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),COORD {x,y});
}

void clrscr() {
	HANDLE hConsole=GetStdHandle(STD_OUTPUT_HANDLE);
	COORD coordScreen= {0,0};
	DWORD cCharsWritten;
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	DWORD dwConSize;
	GetConsoleScreenBufferInfo(hConsole,&csbi);
	dwConSize=csbi.dwSize.X * csbi.dwSize.Y;
	FillConsoleOutputCharacter(hConsole,(TCHAR)' ',dwConSize,coordScreen,&cCharsWritten);
	GetConsoleScreenBufferInfo(hConsole,&csbi);
	FillConsoleOutputAttribute(hConsole,csbi.wAttributes,dwConSize,coordScreen,&cCharsWritten);
	SetConsoleCursorPosition(hConsole,coordScreen);
	return;
}

namespace neo {
	CONSOLE_SCREEN_BUFFER_INFO nowScrInfo;
}

void flushNowScrInfo() {
	GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE),&neo::nowScrInfo);
}

int wherex() {
	flushNowScrInfo();
	return neo::nowScrInfo.dwCursorPosition.X;
}

int wherey() {
	flushNowScrInfo();
	return neo::nowScrInfo.dwCursorPosition.Y;
}

void setcolor(int x){
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),x);
}
