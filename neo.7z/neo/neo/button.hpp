#include <string>
#include <thread>

typedef void(*function)(void);

class button {
	private:
		int x,y,width,height;
		std::string txt;
		function event=NULL;
		bool Erased=0,Begined;
		void showText() {
			gotoxy(x,y);
			int tot=0;
			for(auto ch : txt) {
				if(tot>width*height) break;
				gotoxy(x+tot%width,y+tot/width);
				putchar(ch);
			}
		}
		void listenFun() {
			while(!Erased) {
				if(IsLeftButtonDown()) {
					COORD now=mouse::nowPos;
					if(now.X>=x&&now.X<=x+width&&now.Y>=y&&now.Y<=y+height) {
						event();
					}
					WaitForLeftButtonUp();
				}
				Sleep(5);
			}
		}
	public:
		button() {
			x=y=width=height=0;
			txt="";
		}
		~button() {
			Erased=1;
			Sleep(2);
		}
		void Text(std::string Txt) {
			txt=Txt;
			showText();
		}
		std::string& Text() {
			return txt;   // No flush!
		}
		void Begin(int x,int y,int w,int h,std::string T,function ev) {
			button::x=x;
			button::y=y;
			width=w;
			height=h;
			txt=T;
			event=ev;
			if(!Begined) std::thread listenThread(button::listenFun);
			showText();
			Begined=1;
		}
};
